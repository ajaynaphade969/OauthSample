package com.oauth2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springoauth2projectApplicationTests {

	@Test
	void contextLoads() {
	}

}
